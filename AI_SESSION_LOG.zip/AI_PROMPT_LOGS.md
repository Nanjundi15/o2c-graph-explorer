# 🤖 AI Coding Sessions / Prompt Logs

This document captures the **key prompts and interactions** used to build the SAP O2C Graph Explorer (Frontend + Backend + Deployment).  
Focus is on **practical prompts that directly contributed to development**.

---

## 🧠 1. Project Setup & Architecture

**Prompt:**

```
Build a full-stack application using FastAPI (backend) and React + Vite (frontend). 
The app should visualize SAP O2C data as a graph and include a chat interface for querying data.
```

**Outcome:**

- Backend: FastAPI APIs for graph + analytics + chat
- Frontend: React + Vite UI with graph visualization and chat panel

---

## ⚙️ 2. API Client Structure (Frontend)

**Prompt:**

```
Create a centralized API client in TypeScript where all fetch calls are handled in one place. 
Use generics for typed responses and avoid calling fetch directly inside components.
```

**Outcome:**

- Created `api.ts`
- Implemented reusable `request<T>()`
- Clean separation between UI and API logic

---

## 🔗 3. Environment-Based API Handling

**Prompt:**

```
Handle API base URL dynamically using VITE_API_URL for production and localhost for development.
Ensure it works in both Vite dev server and Vercel deployment.
```

**Outcome:**

```ts
const BASE = import.meta.env.VITE_API_URL
  ? `${import.meta.env.VITE_API_URL}/api`
  : 'http://localhost:8000/api'
```

---

## 🧩 4. Graph Visualization

**Prompt:**

```
Implement a graph view using Cytoscape.js to display entities and relationships.
Allow clicking nodes to fetch and display related records.
```

**Outcome:**

- Interactive graph UI
- Node click → fetch entity records
- Drawer panel for details

---

## 💬 5. Chat System (Data + LLM)

**Prompt:**

```
Create a chat endpoint that answers questions based on SAP O2C data.
Use Groq API for LLM responses and ensure answers are grounded in database results.
```

**Outcome:**

- `/api/chat/query` endpoint
- Data-driven responses
- Guardrails for irrelevant queries

---

## 🛢️ 6. Database Ingestion

**Prompt:**

```
Write an ingest script that reads SAP O2C JSON/CSV data and stores it in SQLite (o2c.db).
Ensure it runs during deployment.
```

**Outcome:**

- `ingest.py` created
- DB auto-generated on build
- Data available for queries

---

## 🚀 7. Backend Deployment (Render)

**Prompt:**

```
Deploy FastAPI backend on Render with a build command that installs dependencies and runs ingest.py.
Set correct database path and environment variables.
```

**Outcome:**

- Build: `pip install -r requirements.txt && python ingest.py`
- Start: `uvicorn main:app --host 0.0.0.0 --port $PORT`
- Fixed DB path:

```
DATABASE_PATH=/opt/render/project/src/o2c.db
```

---

## 🌐 8. Frontend Deployment (Vercel)

**Prompt:**

```
Deploy Vite frontend on Vercel and connect it to the backend using environment variables.
```

**Outcome:**

```
VITE_API_URL = https://your-render-app.onrender.com
```

---

## 🐞 9. Debugging: Blank Screen Issue

**Prompt:**

```
Frontend loads but becomes blank after some time and works again on refresh. 
Debug and identify the cause.
```

**Root Cause:**

- API calls failing due to incorrect backend URL

**Fix:**

- Set `VITE_API_URL` correctly in Vercel
- Ensure BASE URL is not `/api` in production

---

## 🐞 10. Debugging: "No Results" in Production

**Prompt:**

```
Chat works locally but returns "no results" after deployment. Fix the issue.
```

**Root Cause:**

- Wrong database path in Render

**Fix:**

```
DATABASE_PATH=/opt/render/project/src/o2c.db
```

---

## 🧪 11. Backend Verification

**Prompt:**

```
Test backend APIs independently using Postman to verify if issues are frontend or backend related.
```

**Outcome:**

- Confirmed backend working correctly
- Isolated frontend environment issue

---

## ⚡ 12. TypeScript Build Errors (Vercel)

**Prompt:**

```
Fix TypeScript errors that fail during Vercel build but not in local development.
```

**Outcome:**

- Fixed missing types
- Removed invalid syntax (`#`)
- Ensured production build success

---

## 🎯 13. Final Architecture Prompt

**Prompt:**

```
Explain and finalize the architecture for deployment using Vercel + Render with proper API flow.
```

**Outcome:**

```
User → Vercel (Frontend) → Render (Backend) → SQLite DB + Groq API
```

---

## 🧠 Summary

Key areas where AI assistance was used:

- System design & architecture  
- API abstraction  
- Graph visualization  
- Chat + LLM integration  
- Deployment (Render + Vercel)  
- Debugging real-world production issues  

---

## 🚀 Final Result

- Fully working full-stack application  
- Production deployment completed  
- Real-time debugging handled  
- Clean, scalable architecture  
